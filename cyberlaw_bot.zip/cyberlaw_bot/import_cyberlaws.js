// import_cyberlaws.js

const admin = require("firebase-admin");
const fs = require("fs");

// Load service account
const serviceAccount = require("./serviceAccountKey.json");

// Initialize Firebase Admin
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount)
});

const db = admin.firestore();

// Load expanded cyberlaws JSON
const laws = JSON.parse(fs.readFileSync("cyberlaws_expanded.json", "utf8"));


async function clearCollection(collectionName) {
  const snapshot = await db.collection(collectionName).get();
  const batchSize = snapshot.size;

  if (batchSize === 0) return;

  const batch = db.batch();
  snapshot.docs.forEach(doc => {
    batch.delete(doc.ref);
  });

  await batch.commit();
  console.log(`🗑️ Deleted ${batchSize} documents from ${collectionName}`);
}

async function importData() {
  // Step 1: Clear old collection
  await clearCollection("cyberlaws");

  // Step 2: Import fresh laws
  const colRef = db.collection("cyberlaws");
  let count = 0;

  for (const law of laws) {
    await colRef.add(law);
    console.log(`✅ Uploaded: ${law.section} - ${law.title}`);
    count++;
  }

  console.log(`🎉 Successfully uploaded ${count} cyberlaws to Firestore!`);
}

importData().catch(console.error);
